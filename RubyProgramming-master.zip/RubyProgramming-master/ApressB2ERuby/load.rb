# - load vs require

# snake1 = Pet.new()


# x = "Test"
# y = "Shits"

x = "Test"; y = "Shits"; 
if x + y == "TestShits"; puts "Success" else puts "Failure" end
	