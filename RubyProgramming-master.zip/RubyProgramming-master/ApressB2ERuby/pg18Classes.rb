# - Learning with classes
# - Jonathan Cameron
class Animal

	class Person

		def initialize()
			@name = "Unknown Name"
			@age = 00
			@gender = "balls"
		end

		attr_accessor :name, :age, :gender
	end

end
