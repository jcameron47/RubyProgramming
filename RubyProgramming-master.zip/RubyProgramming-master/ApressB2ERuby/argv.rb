# ARGV practice
# Jonathan Cameron

puts ARGV.join('-')