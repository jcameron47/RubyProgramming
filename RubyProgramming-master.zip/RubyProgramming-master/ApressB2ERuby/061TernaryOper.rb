# ?, the Ternary Operator
# Jonathan Cameron

age = 10
type = age < 18 ? "child" : "adult"
puts "You are a " + type

