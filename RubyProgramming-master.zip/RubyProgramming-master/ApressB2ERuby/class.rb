class Pet
	attr_accessor :name, :type, :color
end

