# - fucking with classes n' shit

class Pet

	# def initialize(x)
	# 	@name = x
	# 	@age = 00
	# 	@color = "Plain"

	# 	puts "Pets Initialized"
	# end

	def object
		@snake1 = Pet.new()
		puts "snake1 created"
	end

	attr_accessor :name, :age, :color

end

# snake1 = Pet.new("jackass")