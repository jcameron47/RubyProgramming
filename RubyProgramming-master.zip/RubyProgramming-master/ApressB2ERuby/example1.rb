# pg 79 - Test Source Code File
# Jonathan Cameron

x = 2

print "This application is running okay if 2 + 2 = #{x + x}"
