puts "Hello World!"
puts "Hello Again"
puts "I like typing this"
puts "This is fun."
puts 'Yay! Printing.'
puts "I'd much rather you 'not'."
puts 'I "said" do not touch this.'