puts puts puts puts
#these are comments
puts #nothing
puts "Comment above unseen"