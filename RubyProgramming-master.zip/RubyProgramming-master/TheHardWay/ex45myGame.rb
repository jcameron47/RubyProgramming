# This is where I flex a bit of my programming
# knowledge to my will. Lets get dirty!

# - Jonathan Cameron

require './gamble'

