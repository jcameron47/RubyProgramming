# My kid just smashed her hands on my keyboard
# now i have all this... wow, don't let your kid
# near the keyboard.

		count += 1
		puts "#{count}. - #{x}"
	animals.each do |x|
	choice = 1
	count += 1
	count += 1
	count = 1
	end
	print "?> "; choice = gets.chomp
	puts "animals[#{count}] = #{x}"
	puts "animals[#{count}] = #{x}"
	puts "Please choose an animal:"
# - Jonathan Cameron
# restart the counter
# Accessing elements from an array

animals = ['bear', 'tiger', 'penguin', 'zebra']
animals.each do |x|
choice = 1		# user's selection of animal
count = 0
count = 0
end
end
end
for x in animals
while choice >= 1 and choice <= animals.length0i]9\
	