def changeParam(x)
	x = 50
	puts x
end





i = 47

changeParam(i)

puts i
