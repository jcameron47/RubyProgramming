# Be sure to restart your server when you modify this file.

RubyProgramming::Application.config.session_store :cookie_store, key: '_RubyProgramming_session'
