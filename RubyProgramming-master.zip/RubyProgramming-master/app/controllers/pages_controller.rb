class PagesController < ApplicationController

  def home
  end

  def rubyCode		# Stores all of my code
  end

  def theHardWay	# My completed exercises from http://ruby.learncodethehardway.org/
  end

end
